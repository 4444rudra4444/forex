export class RootTemplate {
    static update(render) {
        render`<app class="arimo"></app>`;
    }
}
