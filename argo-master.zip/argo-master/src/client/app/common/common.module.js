import "./app.module.js";
