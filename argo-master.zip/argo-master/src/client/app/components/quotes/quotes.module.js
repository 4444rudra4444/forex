import { QuotesComponent } from "./quotes.component.js";

QuotesComponent.bootstrap();
