import { ExposureComponent } from "./exposure.component.js";

ExposureComponent.bootstrap();
