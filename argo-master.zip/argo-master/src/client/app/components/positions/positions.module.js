import { PositionsComponent } from "./positions.component.js";

PositionsComponent.bootstrap();
