import { AccountComponent } from "./account.component.js";

AccountComponent.bootstrap();
