import { ActivityComponent } from "./activity.component.js";

ActivityComponent.bootstrap();
