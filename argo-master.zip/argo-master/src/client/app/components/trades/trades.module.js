import { TradesComponent } from "./trades.component.js";

TradesComponent.bootstrap();
