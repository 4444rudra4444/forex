import { ToastsComponent } from "./toasts.component.js";

ToastsComponent.bootstrap();
