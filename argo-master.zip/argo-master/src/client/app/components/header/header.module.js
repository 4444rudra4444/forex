import { HeaderComponent } from "./header.component.js";

HeaderComponent.bootstrap();
