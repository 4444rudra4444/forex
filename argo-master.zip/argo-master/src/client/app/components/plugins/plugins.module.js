import { PluginsComponent } from "./plugins.component.js";

PluginsComponent.bootstrap();
