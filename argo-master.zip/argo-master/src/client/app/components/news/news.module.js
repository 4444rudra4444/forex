import { NewsComponent } from "./news.component.js";

NewsComponent.bootstrap();
