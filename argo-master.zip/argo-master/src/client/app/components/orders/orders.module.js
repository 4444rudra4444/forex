import { OrdersComponent } from "./orders.component.js";

OrdersComponent.bootstrap();
